#include<bits/stdc++.h>
#define Pi 3.1415926535897932384626
using namespace std;
int n;
double ans;
short g[4050][4050];
struct point
{
	int x,y,r;
}a[1005];

double f(int x,int y,int p,int q)
{
	return sqrt((x-p)*(x-p)+(y-q)*(y-q));
}

double ss(int x)
{
	return Pi*x*x;
}

void paint(int x,int y,int z)
{
	for(int i=x-z;i<=x+z;i++)
		for(int j=y-z;j<=y+z;j++)
			if(f(i,j,x,y)<=z)
				g[i+2001][j+2001]=1-g[i+2001][j+2001];
}

bool cmp(point p,point q)
{
	return p.r>q.r;
}

int main()
{
	freopen("circles.in","r",stdin);
	freopen("circles.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].r);
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		double s=ss(a[i].r);
		if(g[a[i].x+2001][a[i].y+2001]==0)
			ans+=s;
		else
			ans-=s;
		paint(a[i].x,a[i].y,a[i].r);
	}
	printf("%0.2lf",ans);
	return 0;
}

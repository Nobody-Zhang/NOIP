#include<bits/stdc++.h>
using namespace std;
int a[10005][2],b[10005][2];
double dis;

double f(int x,int y)
{
	return sqrt((a[x][0]-b[y][0])*(a[x][0]-b[y][0])+(a[x][1]-b[y][1])*(a[x][1]-b[y][1]));
}

double minl(double x,double y)
{
	if(x>y)
		return y;
	return x;
}

int main()
{
	freopen("astray.in","r",stdin);
	freopen("astray.out","w",stdout);
	int sx1,sx2,sy1,sy2,m,s1=0,s2=0;
	scanf("%d%d%d",&sx1,&sy1,&m);
	a[0][0]=sx1;
	a[0][1]=sy1;
	for(int i=1;i<=m;i++)
	{
		int x,y;
		char c;
		scanf("%d",&x);
		getchar();
		scanf("%c",&c);
		if(x>0)
			y=1;
		else
			y=-1;
		if(c=='X')
		{
			for(int j=1;j<=abs(x);j++)
			{
				s1++;
				a[s1][0]=a[s1-1][0]+y;
				a[s1][1]=a[s1-1][1];
			}
		}
		else
		{
			for(int j=1;j<=abs(x);j++)
			{
				s1++;
				a[s1][0]=a[s1-1][0];
				a[s1][1]=a[s1-1][1]+y;
			}
		}
	}
	scanf("%d%d%d",&sx2,&sy2,&m);
	b[0][0]=sx2;
	b[0][1]=sy2;
	for(int i=1;i<=m;i++)
	{
		int x,y;
		char c;
		scanf("%d",&x);
		getchar();
		scanf("%c",&c);
		if(x>0)
			y=1;
		else
			y=-1;
		if(c=='X')
			for(int j=1;j<=abs(x);j++)
			{
				s2++;
				b[s2][0]=b[s2-1][0]+y;
				b[s2][1]=b[s2-1][1];
			}
		else
			for(int j=1;j<=abs(x);j++)
			{
				s2++;
				b[s2][0]=b[s2-1][0];
				b[s2][1]=b[s2-1][1]+y;
			}
	}
	int t1=0,t2=0;
	dis=f(0,0);
	do
	{
		t1++;
		t2++;
		if(t1==s1)
			t1=0;
		if(t2==s2)
			t2=0;
		double s=f(t1,t2);
		dis=minl(dis,s);
		if(dis==0)
			break;
	}
	while(t1!=0||t2!=0);
	printf("%0.2lf",dis);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int n,s,m,a[20005][2],linel[20005],liner[20005];
int main()
{
	freopen("segement.in","r",stdin);
	freopen("segement.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&a[i][0],&a[i][1]);
	liner[1]=a[1][1]-1;
	linel[1]=a[1][1]-1+a[1][1]-a[1][0];
	for(int i=2;i<=n;i++)
	{
		linel[i]=min(linel[i-1]+abs(a[i-1][0]-a[i][1])+a[i][1]-a[i][0],liner[i-1]+abs(a[i-1][1]-a[i][1])+a[i][1]-a[i][0]);
		liner[i]=min(linel[i-1]+abs(a[i-1][0]-a[i][0])+a[i][1]-a[i][0],liner[i-1]+abs(a[i-1][1]-a[i][0])+a[i][1]-a[i][0]);
	}
	printf("%d",min(linel[n]+n-a[n][0],liner[n]+n-a[n][1])+n-1);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;

char a[100005],b[100005];
int xx1,yy1,num1,loc_a=0,pa=0;
int xx2,yy2,num2,loc_b=0,pb=0;

int gcd(int t1,int t2)
{
	if(t1%t2!=0) return gcd(t2,t1%t2);
	else return t2;
}

int main()
{
	freopen ("astray.in","r",stdin);
	freopen ("astray.out","w",stdout);
	
	int tlen;char tdir;
	scanf("%d%d%d",&xx1,&yy1,&num1);
	for(int i=1;i<=num1;i++)
	{
		scanf("%d %c",&tlen,&tdir);
		if(tlen<0){tlen=-tlen;tdir-=2;}
		for(;tlen>0;tlen--)
			a[++loc_a]=tdir;
	}
	scanf("%d%d%d",&xx2,&yy2,&num2);
	for(int i=1;i<=num2;i++)
	{
		scanf("%d %c",&tlen,&tdir);
		if(tlen<0){tlen=-tlen;tdir-=2;}
		for(;tlen>0;tlen--)
			b[++loc_b]=tdir;
	}
	int tmp=gcd(loc_a,loc_b);
	int cs=tmp*(loc_a/tmp)*(loc_b/tmp);
	if(xx1==xx2&&yy1==yy2) {printf("0.00\n");return 0;}
	double ans=sqrt( (double)(xx1-xx2)*(xx1-xx2)+(yy1-yy2)*(yy1-yy2) );
	for(int i=1;i<=cs;i++)
	{
		++pa;if(pa>loc_a) pa=1;
		if(a[pa]=='X') xx1++;
		else if(a[pa]=='Y') yy1++;
		else if(a[pa]=='V') xx1--;
		else if(a[pa]=='W') yy1--;
		++pb;if(pb>loc_b) pb=1;
		if(b[pb]=='X') xx2++;
		else if(b[pb]=='Y') yy2++;
		else if(b[pb]=='V') xx2--;
		else if(b[pb]=='W') yy2--;

		if(xx1==xx2&&yy1==yy2){printf("0.00\n");return 0;}
		else
			ans=min(ans,sqrt( (double)(xx1-xx2)*(xx1-xx2)+(yy1-yy2)*(yy1-yy2) ) );
	}
	printf("%0.2lf\n",ans);
	return 0;
}
